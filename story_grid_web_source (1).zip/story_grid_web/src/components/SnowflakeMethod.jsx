import React, { useState, useEffect } from 'react';
import './snowflake-method.css';

const SnowflakeMethod = () => {
  const [activeStep, setActiveStep] = useState(1);
  const [snowflakeData, setSnowflakeData] = useState({
    // Step 1: One-Sentence Summary
    premise: '',
    
    // Step 2: One-Paragraph Summary
    paragraph_setup: '',
    paragraph_disaster1: '',
    paragraph_disaster2: '',
    paragraph_disaster3: '',
    paragraph_ending: '',
    
    // Step 3: Characters
    characters: [
      {
        id: 1,
        name: 'Character 1',
        ambition: '',
        storygoal: '',
        conflict: '',
        epiphany: '',
        summary: ''
      }
    ],
    
    // Step 4: Expanded Paragraph
    plot_setup_expanded: '',
    plot_disaster1_expanded: '',
    plot_disaster2_expanded: '',
    plot_disaster3_expanded: '',
    plot_ending_expanded: '',
    
    // Step 5: Character Synopses
    character_synopses: {},
    
    // Step 6: Four-Page Synopsis
    sceneOutline: '',
    
    // Step 7: Character Details
    character_details: {},
    
    // Step 8: Scene List
    scenes: [],
    
    // Step 9: First Draft Notes
    firstDraftNotes: ''
  });
  const [activeCharacter, setActiveCharacter] = useState(1);
  const [nextSceneId, setNextSceneId] = useState(1);

  // Initialize character_synopses and character_details when characters change
  useEffect(() => {
    const updatedSynopses = { ...snowflakeData.character_synopses };
    const updatedDetails = { ...snowflakeData.character_details };
    
    snowflakeData.characters.forEach(char => {
      if (!updatedSynopses[char.id]) {
        updatedSynopses[char.id] = '';
      }
      
      if (!updatedDetails[char.id]) {
        updatedDetails[char.id] = {
          physical: '',
          background: '',
          personality: '',
          relationships: '',
          arc: ''
        };
      }
    });
    
    // Remove synopses and details for deleted characters
    Object.keys(updatedSynopses).forEach(id => {
      if (!snowflakeData.characters.some(char => char.id === parseInt(id))) {
        delete updatedSynopses[id];
      }
    });
    
    Object.keys(updatedDetails).forEach(id => {
      if (!snowflakeData.characters.some(char => char.id === parseInt(id))) {
        delete updatedDetails[id];
      }
    });
    
    setSnowflakeData(prev => ({
      ...prev,
      character_synopses: updatedSynopses,
      character_details: updatedDetails
    }));
  }, [snowflakeData.characters]);

  const handlePreviousStep = () => {
    if (activeStep > 1) {
      setActiveStep(activeStep - 1);
    }
  };

  const handleNextStep = () => {
    if (activeStep < 9) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleInputChange = (field, value) => {
    setSnowflakeData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCharacterChange = (charId, field, value) => {
    setSnowflakeData(prev => ({
      ...prev,
      characters: prev.characters.map(char => 
        char.id === charId ? { ...char, [field]: value } : char
      )
    }));
  };

  const handleCharacterSynopsisChange = (charId, value) => {
    setSnowflakeData(prev => ({
      ...prev,
      character_synopses: {
        ...prev.character_synopses,
        [charId]: value
      }
    }));
  };

  const handleCharacterDetailChange = (charId, field, value) => {
    setSnowflakeData(prev => ({
      ...prev,
      character_details: {
        ...prev.character_details,
        [charId]: {
          ...prev.character_details[charId],
          [field]: value
        }
      }
    }));
  };

  const handleAddCharacter = () => {
    const newCharId = Math.max(0, ...snowflakeData.characters.map(char => char.id)) + 1;
    
    setSnowflakeData(prev => ({
      ...prev,
      characters: [
        ...prev.characters,
        {
          id: newCharId,
          name: `Character ${newCharId}`,
          ambition: '',
          storygoal: '',
          conflict: '',
          epiphany: '',
          summary: ''
        }
      ]
    }));
    
    setActiveCharacter(newCharId);
  };

  const handleDeleteCharacter = (charId) => {
    if (snowflakeData.characters.length <= 1) {
      alert("You must have at least one character.");
      return;
    }
    
    setSnowflakeData(prev => ({
      ...prev,
      characters: prev.characters.filter(char => char.id !== charId)
    }));
    
    // Set active character to the first one if the active character was deleted
    if (activeCharacter === charId) {
      const remainingChars = snowflakeData.characters.filter(char => char.id !== charId);
      if (remainingChars.length > 0) {
        setActiveCharacter(remainingChars[0].id);
      }
    }
  };

  const handleAddScene = () => {
    setSnowflakeData(prev => ({
      ...prev,
      scenes: [
        ...prev.scenes,
        {
          id: nextSceneId,
          title: `Scene ${nextSceneId}`,
          pov: '',
          setting: '',
          timeframe: '',
          description: ''
        }
      ]
    }));
    
    setNextSceneId(nextSceneId + 1);
  };

  const handleDeleteScene = (sceneId) => {
    setSnowflakeData(prev => ({
      ...prev,
      scenes: prev.scenes.filter(scene => scene.id !== sceneId)
    }));
  };

  const handleSceneChange = (sceneId, field, value) => {
    setSnowflakeData(prev => ({
      ...prev,
      scenes: prev.scenes.map(scene => 
        scene.id === sceneId ? { ...scene, [field]: value } : scene
      )
    }));
  };

  const handleSaveDraft = () => {
    try {
      localStorage.setItem('snowflakeData', JSON.stringify(snowflakeData));
      alert('Draft saved successfully!');
    } catch (error) {
      console.error('Error saving draft:', error);
      alert('Failed to save draft. Please try again.');
    }
  };

  const handleExportDraft = () => {
    try {
      // Create a formatted text representation of the snowflake data
      let exportText = `# SNOWFLAKE METHOD DRAFT\n\n`;
      
      // Step 1
      exportText += `## STEP 1: ONE-SENTENCE SUMMARY\n${snowflakeData.premise || '[Not completed]'}\n\n`;
      
      // Step 2
      exportText += `## STEP 2: ONE-PARAGRAPH SUMMARY\n`;
      exportText += `Setup: ${snowflakeData.paragraph_setup || '[Not completed]'}\n`;
      exportText += `Disaster 1: ${snowflakeData.paragraph_disaster1 || '[Not completed]'}\n`;
      exportText += `Disaster 2: ${snowflakeData.paragraph_disaster2 || '[Not completed]'}\n`;
      exportText += `Disaster 3: ${snowflakeData.paragraph_disaster3 || '[Not completed]'}\n`;
      exportText += `Ending: ${snowflakeData.paragraph_ending || '[Not completed]'}\n\n`;
      
      // Step 3
      exportText += `## STEP 3: CHARACTER SUMMARIES\n`;
      snowflakeData.characters.forEach(char => {
        exportText += `### ${char.name}\n`;
        exportText += `Ambition: ${char.ambition || '[Not completed]'}\n`;
        exportText += `Story Goal: ${char.storygoal || '[Not completed]'}\n`;
        exportText += `Conflict: ${char.conflict || '[Not completed]'}\n`;
        exportText += `Epiphany: ${char.epiphany || '[Not completed]'}\n`;
        exportText += `One-Sentence Summary: ${char.summary || '[Not completed]'}\n\n`;
      });
      
      // Step 4
      exportText += `## STEP 4: EXPANDED PARAGRAPH\n`;
      exportText += `Setup (Expanded): ${snowflakeData.plot_setup_expanded || '[Not completed]'}\n`;
      exportText += `Disaster 1 (Expanded): ${snowflakeData.plot_disaster1_expanded || '[Not completed]'}\n`;
      exportText += `Disaster 2 (Expanded): ${snowflakeData.plot_disaster2_expanded || '[Not completed]'}\n`;
      exportText += `Disaster 3 (Expanded): ${snowflakeData.plot_disaster3_expanded || '[Not completed]'}\n`;
      exportText += `Ending (Expanded): ${snowflakeData.plot_ending_expanded || '[Not completed]'}\n\n`;
      
      // Step 5
      exportText += `## STEP 5: CHARACTER SYNOPSES\n`;
      snowflakeData.characters.forEach(char => {
        exportText += `### ${char.name} Synopsis\n`;
        exportText += `${snowflakeData.character_synopses[char.id] || '[Not completed]'}\n\n`;
      });
      
      // Step 6
      exportText += `## STEP 6: FOUR-PAGE SYNOPSIS\n${snowflakeData.sceneOutline || '[Not completed]'}\n\n`;
      
      // Step 7
      exportText += `## STEP 7: CHARACTER DETAILS\n`;
      snowflakeData.characters.forEach(char => {
        const details = snowflakeData.character_details[char.id] || {};
        exportText += `### ${char.name} Details\n`;
        exportText += `Physical Description: ${details.physical || '[Not completed]'}\n`;
        exportText += `Background: ${details.background || '[Not completed]'}\n`;
        exportText += `Personality: ${details.personality || '[Not completed]'}\n`;
        exportText += `Relationships: ${details.relationships || '[Not completed]'}\n`;
        exportText += `Character Arc: ${details.arc || '[Not completed]'}\n\n`;
      });
      
      // Step 8
      exportText += `## STEP 8: SCENE LIST\n`;
      if (snowflakeData.scenes.length === 0) {
        exportText += `[No scenes added yet]\n\n`;
      } else {
        snowflakeData.scenes.forEach(scene => {
          exportText += `### ${scene.title}\n`;
          exportText += `POV Character: ${scene.pov || '[Not specified]'}\n`;
          exportText += `Setting: ${scene.setting || '[Not specified]'}\n`;
          exportText += `Timeframe: ${scene.timeframe || '[Not specified]'}\n`;
          exportText += `Description: ${scene.description || '[Not specified]'}\n\n`;
        });
      }
      
      // Step 9
      exportText += `## STEP 9: FIRST DRAFT NOTES\n${snowflakeData.firstDraftNotes || '[Not completed]'}\n`;
      
      // Create and trigger download
      const blob = new Blob([exportText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'snowflake_method_draft.txt';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error exporting draft:', error);
      alert('Failed to export draft. Please try again.');
    }
  };

  const handleResetDraft = () => {
    if (window.confirm('Are you sure you want to reset your draft? This will clear all your data.')) {
      setSnowflakeData({
        premise: '',
        paragraph_setup: '',
        paragraph_disaster1: '',
        paragraph_disaster2: '',
        paragraph_disaster3: '',
        paragraph_ending: '',
        characters: [
          {
            id: 1,
            name: 'Character 1',
            ambition: '',
            storygoal: '',
            conflict: '',
            epiphany: '',
            summary: ''
          }
        ],
        plot_setup_expanded: '',
        plot_disaster1_expanded: '',
        plot_disaster2_expanded: '',
        plot_disaster3_expanded: '',
        plot_ending_expanded: '',
        character_synopses: {},
        sceneOutline: '',
        character_details: {},
        scenes: [],
        firstDraftNotes: ''
      });
      setActiveCharacter(1);
      setNextSceneId(1);
      setActiveStep(1);
      
      localStorage.removeItem('snowflakeData');
      alert('Draft has been reset.');
    }
  };

  // Load saved data on component mount
  useEffect(() => {
    try {
      const savedData = localStorage.getItem('snowflakeData');
      if (savedData) {
        setSnowflakeData(JSON.parse(savedData));
        
        // Set nextSceneId to be greater than any existing scene id
        const parsedData = JSON.parse(savedData);
        if (parsedData.scenes && parsedData.scenes.length > 0) {
          const maxId = Math.max(...parsedData.scenes.map(scene => scene.id), 0);
          setNextSceneId(maxId + 1);
        }
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
  }, []);

  // Calculate progress percentage
  const calculateProgress = () => {
    let totalFields = 0;
    let completedFields = 0;
    
    // Step 1: One field
    totalFields += 1;
    if (snowflakeData.premise) completedFields += 1;
    
    // Step 2: Five fields
    totalFields += 5;
    if (snowflakeData.paragraph_setup) completedFields += 1;
    if (snowflakeData.paragraph_disaster1) completedFields += 1;
    if (snowflakeData.paragraph_disaster2) completedFields += 1;
    if (snowflakeData.paragraph_disaster3) completedFields += 1;
    if (snowflakeData.paragraph_ending) completedFields += 1;
    
    // Step 3: Five fields per character
    const charFields = snowflakeData.characters.length * 5;
    totalFields += charFields;
    snowflakeData.characters.forEach(char => {
      if (char.ambition) completedFields += 1;
      if (char.storygoal) completedFields += 1;
      if (char.conflict) completedFields += 1;
      if (char.epiphany) completedFields += 1;
      if (char.summary) completedFields += 1;
    });
    
    // Step 4: Five fields
    totalFields += 5;
    if (snowflakeData.plot_setup_expanded) completedFields += 1;
    if (snowflakeData.plot_disaster1_expanded) completedFields += 1;
    if (snowflakeData.plot_disaster2_expanded) completedFields += 1;
    if (snowflakeData.plot_disaster3_expanded) completedFields += 1;
    if (snowflakeData.plot_ending_expanded) completedFields += 1;
    
    // Step 5: One field per character
    totalFields += snowflakeData.characters.length;
    snowflakeData.characters.forEach(char => {
      if (snowflakeData.character_synopses[char.id]) completedFields += 1;
    });
    
    // Step 6: One field
    totalFields += 1;
    if (snowflakeData.sceneOutline) completedFields += 1;
    
    // Step 7: Five fields per character
    totalFields += snowflakeData.characters.length * 5;
    snowflakeData.characters.forEach(char => {
      const details = snowflakeData.character_details[char.id] || {};
      if (details.physical) completedFields += 1;
      if (details.background) completedFields += 1;
      if (details.personality) completedFields += 1;
      if (details.relationships) completedFields += 1;
      if (details.arc) completedFields += 1;
    });
    
    // Step 8: Four fields per scene (minimum 1 scene expected)
    const sceneCount = Math.max(1, snowflakeData.scenes.length);
    totalFields += sceneCount * 4;
    snowflakeData.scenes.forEach(scene => {
      if (scene.pov) completedFields += 1;
      if (scene.setting) completedFields += 1;
      if (scene.timeframe) completedFields += 1;
      if (scene.description) completedFields += 1;
    });
    
    // Step 9: One field
    totalFields += 1;
    if (snowflakeData.firstDraftNotes) completedFields += 1;
    
    return Math.round((completedFields / totalFields) * 100);
  };

  // Render step content based on active step
  const renderStepContent = () => {
    switch (activeStep) {
      case 1:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">1</span>
              Write a One-Sentence Summary
            </h3>
            <p>Summarize your entire novel in a single sentence. This is your elevator pitch, the core concept of your story.</p>
            
            <div className="example-box">
              <p><strong>Example:</strong> A young wizard discovers he's destined to defeat a dark lord who killed his parents.</p>
            </div>
            
            <div className="field-container">
              <label htmlFor="premise">Your One-Sentence Summary:</label>
              <textarea
                id="premise"
                className="snowflake-textarea"
                value={snowflakeData.premise}
                onChange={(e) => handleInputChange('premise', e.target.value)}
                placeholder="Write your one-sentence summary here..."
              />
            </div>
          </div>
        );
        
      case 2:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">2</span>
              Expand to a One-Paragraph Summary
            </h3>
            <p>Expand your one-sentence summary into a full paragraph with five components: setup, three disasters, and ending.</p>
            
            <div className="field-container">
              <label htmlFor="paragraph_setup">Setup:</label>
                  <div className="example-box">
              <p><strong>Example Setup:</strong> A boy discovers he's a famous wizard and goes to magic school.</p>
            </div>
              <textarea
                id="paragraph_setup"
                className="snowflake-textarea"
                value={snowflakeData.paragraph_setup}
                onChange={(e) => handleInputChange('paragraph_setup', e.target.value)}
                placeholder="Describe the initial setup of your story..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="paragraph_disaster1">First Disaster/Complication:</label>
              <textarea
                id="paragraph_disaster1"
                className="snowflake-textarea"
                value={snowflakeData.paragraph_disaster1}
                onChange={(e) => handleInputChange('paragraph_disaster1', e.target.value)}
                placeholder="Describe the first major complication..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="paragraph_disaster2">Second Disaster/Complication:</label>
              <textarea
                id="paragraph_disaster2"
                className="snowflake-textarea"
                value={snowflakeData.paragraph_disaster2}
                onChange={(e) => handleInputChange('paragraph_disaster2', e.target.value)}
                placeholder="Describe the second major complication..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="paragraph_disaster3">Third Disaster/Complication:</label>
              <textarea
                id="paragraph_disaster3"
                className="snowflake-textarea"
                value={snowflakeData.paragraph_disaster3}
                onChange={(e) => handleInputChange('paragraph_disaster3', e.target.value)}
                placeholder="Describe the third major complication..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="paragraph_ending">Ending:</label>
                  <div className="example-box">
              <p><strong>Example Ending:</strong> The boy confronts the villain and saves the magical object.</p>
            </div>
              <textarea
                id="paragraph_ending"
                className="snowflake-textarea"
                value={snowflakeData.paragraph_ending}
                onChange={(e) => handleInputChange('paragraph_ending', e.target.value)}
                placeholder="Describe how the story ends..."
              />
            </div>
          </div>
        );
        
      case 3:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">3</span>
              Define Your Characters
            </h3>
            <p>For each major character, create a summary sheet. Characters are the most important part of any novel, and the time invested in designing them will pay off tenfold.</p>
            
            <div className="character-management">
              <div className="character-list">
                <button className="add-character-button" onClick={handleAddCharacter}>
                  + Add Character
                </button>
                
                {snowflakeData.characters.map(char => (
                  <div
                    key={char.id}
                    className={`character-tab ${activeCharacter === char.id ? 'active' : ''}`}
                    onClick={() => setActiveCharacter(char.id)}
                  >
                    <div className="character-tab-content">
                      <span>{char.name}</span>
                      {snowflakeData.characters.length > 1 && (
                        <button
                          className="delete-character-button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteCharacter(char.id);
                          }}
                        >
                          ×
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="character-details">
                {snowflakeData.characters.map(char => {
                  if (char.id === activeCharacter) {
                    return (
                      <div key={char.id}>
                        <h4>Character Details:</h4>
                        
                        <div className="character-field">
                          <label htmlFor={`char-name-${char.id}`}>Name:</label>
                          <input
                            id={`char-name-${char.id}`}
                            type="text"
                            value={char.name}
                            onChange={(e) => handleCharacterChange(char.id, 'name', e.target.value)}
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-ambition-${char.id}`}>Ambition:</label>
                          <textarea
                            id={`char-ambition-${char.id}`}
                            value={char.ambition}
                            onChange={(e) => handleCharacterChange(char.id, 'ambition', e.target.value)}
                            placeholder="What does this character want abstractly?"
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-storygoal-${char.id}`}>Story Goal:</label>
                          <textarea
                            id={`char-storygoal-${char.id}`}
                            value={char.storygoal}
                            onChange={(e) => handleCharacterChange(char.id, 'storygoal', e.target.value)}
                            placeholder="What does this character want concretely?"
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-conflict-${char.id}`}>Conflict:</label>
                          <textarea
                            id={`char-conflict-${char.id}`}
                            value={char.conflict}
                            onChange={(e) => handleCharacterChange(char.id, 'conflict', e.target.value)}
                            placeholder="What prevents them from reaching this goal?"
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-epiphany-${char.id}`}>Epiphany:</label>
                          <textarea
                            id={`char-epiphany-${char.id}`}
                            value={char.epiphany}
                            onChange={(e) => handleCharacterChange(char.id, 'epiphany', e.target.value)}
                            placeholder="What will they learn, how will they change?"
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-summary-${char.id}`}>Sentence Summary:</label>
                          <div className="example-box">
                            <p><strong>Example:</strong> Describe how this character changes from an insecure novice wizard to a brave hero throughout the story.</p>
                          </div>
                          <textarea
                            id={`char-summary-${char.id}`}
                            value={char.summary}
                            onChange={(e) => handleCharacterChange(char.id, 'summary', e.target.value)}
                            placeholder="Write a one-sentence summary for this character..."
                          />
                        </div>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          </div>
        );
        
      case 4:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">4</span>
              Expand Each Paragraph Point
            </h3>
            <p>Take each sentence from your one-paragraph summary and expand it into a full paragraph. This gives you a one-page summary of your novel.</p>
            
            <div className="field-container">
              <label htmlFor="plot_setup_expanded">Setup (Expanded):</label>
                <div className="example-box">
              <p><strong>Example:</strong> The magical world has hidden rules and dangers that the young wizard must learn to navigate.</p>
            </div>
              <textarea
                id="plot_setup_expanded"
                className="snowflake-textarea large"
                value={snowflakeData.plot_setup_expanded}
                onChange={(e) => handleInputChange('plot_setup_expanded', e.target.value)}
                placeholder="Expand your setup into a full paragraph..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="plot_disaster1_expanded">First Disaster/Complication (Expanded):</label>
              <textarea
                id="plot_disaster1_expanded"
                className="snowflake-textarea large"
                value={snowflakeData.plot_disaster1_expanded}
                onChange={(e) => handleInputChange('plot_disaster1_expanded', e.target.value)}
                placeholder="Expand your first disaster into a full paragraph..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="plot_disaster2_expanded">Second Disaster/Complication (Expanded):</label>
              <textarea
                id="plot_disaster2_expanded"
                className="snowflake-textarea large"
                value={snowflakeData.plot_disaster2_expanded}
                onChange={(e) => handleInputChange('plot_disaster2_expanded', e.target.value)}
                placeholder="Expand your second disaster into a full paragraph..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="plot_disaster3_expanded">Third Disaster/Complication (Expanded):</label>
              <textarea
                id="plot_disaster3_expanded"
                className="snowflake-textarea large"
                value={snowflakeData.plot_disaster3_expanded}
                onChange={(e) => handleInputChange('plot_disaster3_expanded', e.target.value)}
                placeholder="Expand your third disaster into a full paragraph..."
              />
            </div>
            
            <div className="field-container">
              <label htmlFor="plot_ending_expanded">Ending (Expanded):</label>
              <textarea
                id="plot_ending_expanded"
                className="snowflake-textarea large"
                value={snowflakeData.plot_ending_expanded}
                onChange={(e) => handleInputChange('plot_ending_expanded', e.target.value)}
                placeholder="Expand your ending into a full paragraph..."
              />
            </div>
          </div>
        );
        
      case 5:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">5</span>
              Write Character Synopses
            </h3>
            <p>Write a one-page synopsis for each major character, describing their storyline throughout the novel.</p>
            
            <div className="character-management">
              <div className="character-list">
                {snowflakeData.characters.map(char => (
                  <div
                    key={char.id}
                    className={`character-tab ${activeCharacter === char.id ? 'active' : ''}`}
                    onClick={() => setActiveCharacter(char.id)}
                  >
                    <span>{char.name}</span>
                  </div>
                ))}
              </div>
              
              <div className="character-details">
                {snowflakeData.characters.map(char => {
                  if (char.id === activeCharacter) {
                    return (
                      <div key={char.id} className="character-field full-width">
                        <label htmlFor={`char-synopsis-${char.id}`}>{char.name}'s Synopsis:</label>
                        <textarea
                          id={`char-synopsis-${char.id}`}
                          value={snowflakeData.character_synopses[char.id] || ''}
                          onChange={(e) => handleCharacterSynopsisChange(char.id, e.target.value)}
                          placeholder={`Write a one-page synopsis for ${char.name}...`}
                        />
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          </div>
        );
        
      case 6:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">6</span>
              Expand Your One-Page Synopsis
            </h3>
            <p>Expand your one-page synopsis into a four-page synopsis. This gives you a solid foundation for your novel's structure.</p>
            
            <div className="field-container">
              <label htmlFor="sceneOutline">Four-Page Synopsis:</label>
              <div className="example-box">
                <p><strong>Tip:</strong> Think about key magical artifacts, spells, or locations that could serve as powerful symbols in your story.</p>
              </div>
              <textarea
                id="sceneOutline"
                className="snowflake-textarea large"
                style={{ minHeight: '400px' }}
                value={snowflakeData.sceneOutline}
                onChange={(e) => handleInputChange('sceneOutline', e.target.value)}
                placeholder="Write your expanded four-page synopsis here..."
              />
            </div>
          </div>
        );
        
      case 7:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">7</span>
              Develop Character Details
            </h3>
            <p>Create full character charts for each major character, including background, personality traits, and relationships.</p>
            
            <div className="character-management">
              <div className="character-list">
                {snowflakeData.characters.map(char => (
                  <div
                    key={char.id}
                    className={`character-tab ${activeCharacter === char.id ? 'active' : ''}`}
                    onClick={() => setActiveCharacter(char.id)}
                  >
                    <span>{char.name}</span>
                  </div>
                ))}
              </div>
              
              <div className="character-details">
                {snowflakeData.characters.map(char => {
                  if (char.id === activeCharacter) {
                    const details = snowflakeData.character_details[char.id] || {};
                    
                    return (
                      <div key={char.id}>
                        <h4>{char.name}'s Detailed Profile</h4>
                        
                        <div className="character-field">
                          <label htmlFor={`char-physical-${char.id}`}>Physical Description:</label>
                          <textarea
                            id={`char-physical-${char.id}`}
                            value={details.physical || ''}
                            onChange={(e) => handleCharacterDetailChange(char.id, 'physical', e.target.value)}
                            placeholder="Describe physical appearance, mannerisms, voice, etc..."
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-background-${char.id}`}>Background/History:</label>
                          <textarea
                            id={`char-background-${char.id}`}
                            value={details.background || ''}
                            onChange={(e) => handleCharacterDetailChange(char.id, 'background', e.target.value)}
                            placeholder="Describe this character's background and history..."
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-personality-${char.id}`}>Personality:</label>
                          <textarea
                            id={`char-personality-${char.id}`}
                            value={details.personality || ''}
                            onChange={(e) => handleCharacterDetailChange(char.id, 'personality', e.target.value)}
                            placeholder="Describe personality traits, quirks, strengths, flaws..."
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-relationships-${char.id}`}>Relationships:</label>
                          <textarea
                            id={`char-relationships-${char.id}`}
                            value={details.relationships || ''}
                            onChange={(e) => handleCharacterDetailChange(char.id, 'relationships', e.target.value)}
                            placeholder="Describe relationships with other characters..."
                          />
                        </div>
                        
                        <div className="character-field">
                          <label htmlFor={`char-arc-${char.id}`}>Character Arc:</label>
                          <textarea
                            id={`char-arc-${char.id}`}
                            value={details.arc || ''}
                            onChange={(e) => handleCharacterDetailChange(char.id, 'arc', e.target.value)}
                            placeholder="Describe how this character changes throughout the story..."
                          />
                        </div>
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            </div>
          </div>
        );
        
      case 8:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">8</span>
              Create Your Scene List
            </h3>
            <p>Make a list of every scene you'll need to write to complete your novel. This becomes your roadmap for the first draft.</p>
            
            <button className="add-scene-button" onClick={handleAddScene}>
              + Add Scene
            </button>
            
            {snowflakeData.scenes.length === 0 ? (
              <div className="no-scenes-message">
                <p>No scenes added yet. Click the button above to add your first scene.</p>
              </div>
            ) : (
              <div className="scenes-list">
                {snowflakeData.scenes.map(scene => (
                  <div key={scene.id} className="scene-item">
                    <div className="scene-header">
                      <h4>{scene.title}</h4>
                      <button
                        className="delete-scene-button"
                        onClick={() => handleDeleteScene(scene.id)}
                      >
                        Delete
                      </button>
                    </div>
                    
                    <div className="scene-fields">
                      <div className="scene-field">
                        <label htmlFor={`scene-title-${scene.id}`}>Scene Title:</label>
                        <input
                          id={`scene-title-${scene.id}`}
                          type="text"
                          value={scene.title}
                          onChange={(e) => handleSceneChange(scene.id, 'title', e.target.value)}
                        />
                      </div>
                      
                      <div className="scene-field">
                        <label htmlFor={`scene-pov-${scene.id}`}>POV Character:</label>
                        <input
                          id={`scene-pov-${scene.id}`}
                          type="text"
                          value={scene.pov}
                          onChange={(e) => handleSceneChange(scene.id, 'pov', e.target.value)}
                        />
                      </div>
                      
                      <div className="scene-field">
                        <label htmlFor={`scene-setting-${scene.id}`}>Setting:</label>
                        <input
                          id={`scene-setting-${scene.id}`}
                          type="text"
                          value={scene.setting}
                          onChange={(e) => handleSceneChange(scene.id, 'setting', e.target.value)}
                        />
                      </div>
                      
                      <div className="scene-field">
                        <label htmlFor={`scene-timeframe-${scene.id}`}>Timeframe:</label>
                        <input
                          id={`scene-timeframe-${scene.id}`}
                          type="text"
                          value={scene.timeframe}
                          onChange={(e) => handleSceneChange(scene.id, 'timeframe', e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div className="scene-field">
                      <label htmlFor={`scene-description-${scene.id}`}>Description:</label>
                      <textarea
                        id={`scene-description-${scene.id}`}
                        value={scene.description}
                        onChange={(e) => handleSceneChange(scene.id, 'description', e.target.value)}
                        placeholder="Describe what happens in this scene..."
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
        
      case 9:
        return (
          <div className="snowflake-content">
            <h3 className="step-title">
              <span className="step-number">9</span>
              Prepare for Your First Draft
            </h3>
            <p>You're now ready to write your first draft! Use this space for any final notes or thoughts before you begin.</p>
            
            <div className="field-container">
              <label htmlFor="firstDraftNotes">First Draft Notes:</label>
              <textarea
                id="firstDraftNotes"
                className="snowflake-textarea large"
                style={{ minHeight: '300px' }}
                value={snowflakeData.firstDraftNotes}
                onChange={(e) => handleInputChange('firstDraftNotes', e.target.value)}
                placeholder="Write any final notes, thoughts, or reminders for your first draft..."
              />
            </div>
            
            <div className="congratulations-message">
              <h4>Congratulations!</h4>
              <p>You've completed the Snowflake Method! You now have a solid foundation for writing your novel. Use your scene list as a roadmap and start writing your first draft.</p>
            </div>
          </div>
        );
        
      default:
        return <div>Invalid step</div>;
    }
  };

  // Calculate progress percentage
  const progressPercentage = calculateProgress();

  return (
    <div className="snowflake-method-container">
      <div className="snowflake-header">
        <h2>Snowflake Method</h2>
        <div className="snowflake-actions">
          <button className="snowflake-button save" onClick={handleSaveDraft}>Save Draft</button>
          <button className="snowflake-button export" onClick={handleExportDraft}>Export Draft</button>
          <button className="snowflake-button reset" onClick={handleResetDraft}>Reset</button>
        </div>
      </div>
      
      <p className="snowflake-description">
        The Snowflake Method is a step-by-step approach to writing a novel, starting with a simple premise and gradually expanding it into a complete story.
      </p>
      
      <div className="progress-bar-container">
        <div className="progress-bar" style={{ width: `${progressPercentage}%` }}></div>
      </div>
      
      <div className="breadcrumb-nav">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(step => (
          <div
            key={step}
            className={`breadcrumb-item ${activeStep === step ? 'active' : ''}`}
            onClick={() => setActiveStep(step)}
          >
            {step}. {
              step === 1 ? 'One-Sentence' :
              step === 2 ? 'One-Paragraph' :
              step === 3 ? 'Characters' :
              step === 4 ? 'Expanded Paragraph' :
              step === 5 ? 'Character Synopses' :
              step === 6 ? 'Four-Page Synopsis' :
              step === 7 ? 'Character Details' :
              step === 8 ? 'Scene List' :
              'First Draft'
            }
          </div>
        ))}
      </div>
      
      {renderStepContent()}
      
      <div className="navigation-buttons">
        <button
          className="nav-button"
          onClick={handlePreviousStep}
          disabled={activeStep === 1}
        >
          ← Previous Step
        </button>
        <button
          className="nav-button next"
          onClick={handleNextStep}
          disabled={activeStep === 9}
        >
          Next Step →
        </button>
      </div>
      
      <div className="snowflake-footer">
        
      </div>
    </div>
  );
};

export default SnowflakeMethod;
