import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './storytelling.css';

const ModeSelector = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;
  
  // Determine active mode based on current path
  const mode = currentPath.includes('snowflake') ? 'snowflake' : 'grid';
  
  const handleModeChange = (newMode) => {
    navigate(newMode === 'grid' ? '/grid' : '/snowflake');
  };
  
  return (
    <div className="mode-selector">
      <button
        className={`mode-button ${mode === 'grid' ? 'active' : ''}`}
        onClick={() => handleModeChange('grid')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="3" width="7" height="7"></rect>
          <rect x="14" y="3" width="7" height="7"></rect>
          <rect x="14" y="14" width="7" height="7"></rect>
          <rect x="3" y="14" width="7" height="7"></rect>
        </svg>
        Narrative Grid
      </button>
      <button
        className={`mode-button ${mode === 'snowflake' ? 'active' : ''}`}
        onClick={() => handleModeChange('snowflake')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2v20M4.93 4.93l14.14 14.14M2 12h20M4.93 19.07l14.14-14.14"></path>
        </svg>
        Snowflake Method
      </button>
    </div>
  );
};

export default ModeSelector;
