import React, { useState, useEffect, useRef } from 'react';
import './narrative-grid.css';

const NarrativeGridEditor = () => {
  const [title, setTitle] = useState('Untitled Story');
  const [author, setAuthor] = useState('Anonymous');
  const [columns, setColumns] = useState([
    'Act',
    'Plot Movement (What Happens)',
    'Character Evolution',
    'Core Theme / Message',
    'Supporting Subplot(s)',
    'Relationship Dynamics',
    'Setting / Location',
    'Point of View (POV)',
    'Emotional Beats',
    'Conflict Type',
    'Scene Value Shift',
    'Turning Points',
    'Pacing / Tension',
    'Symbolism / Motifs'
  ]);
  const [rows, setRows] = useState([
    {
      id: 1,
      cells: {
        'Act': '1',
        'Plot Movement (What Happens)': 'The protagonist\'s routine is disrupted by a strange letter.',
        'Character Evolution': 'Feels trapped in monotony; begins to question their reality.',
        'Core Theme / Message': 'Isolation vs. connection',
        'Supporting Subplot(s)': 'Friend\'s new job opportunity abroad causes distance.',
        'Relationship Dynamics': 'Strained connection with best friend.',
        'Setting / Location': 'Small town bookstore',
        'Point of View (POV)': 'First-person (Protagonist)',
        'Emotional Beats': 'Curiosity, anxiety, hope',
        'Conflict Type': 'Internal - identity crisis',
        'Scene Value Shift': 'Complacency → Uncertainty',
        'Turning Points': 'Discovery of the mysterious letter',
        'Pacing / Tension': 'Slow build with sudden revelation',
        'Symbolism / Motifs': 'Unopened letters, clocks, closed doors'
      }
    }
  ]);
  const [nextRowId, setNextRowId] = useState(2);
  const [showColumnModal, setShowColumnModal] = useState(false);
  const [editingColumns, setEditingColumns] = useState([]);
  const [draggedRowIndex, setDraggedRowIndex] = useState(null);
  const [draggedColumnIndex, setDraggedColumnIndex] = useState(null);
  
  // Initialize editing columns when modal opens
  useEffect(() => {
    if (showColumnModal) {
      setEditingColumns([...columns]);
    }
  }, [showColumnModal]);

  // Handle row addition
  const handleAddRow = () => {
    const newRow = {
      id: nextRowId,
      cells: {}
    };
    
    // Initialize cells for all columns
    columns.forEach(column => {
      newRow.cells[column] = '';
    });
    
    setRows([...rows, newRow]);
    setNextRowId(nextRowId + 1);
  };

  // Handle row deletion
  const handleDeleteRow = (rowId) => {
    setRows(rows.filter(row => row.id !== rowId));
  };

  // Handle cell content change
  const handleCellChange = (rowId, column, value) => {
    setRows(rows.map(row => {
      if (row.id === rowId) {
        return {
          ...row,
          cells: {
            ...row.cells,
            [column]: value
          }
        };
      }
      return row;
    }));
  };

  // Handle column header change
  const handleColumnChange = (index, value) => {
    setEditingColumns(editingColumns.map((col, i) => i === index ? value : col));
  };

  // Handle adding a new column in the modal
  const handleAddColumn = () => {
    setEditingColumns([...editingColumns, 'New Column']);
  };

  // Handle deleting a column in the modal
  const handleDeleteColumn = (index) => {
    setEditingColumns(editingColumns.filter((_, i) => i !== index));
  };

  // Save column changes
  const handleSaveColumns = () => {
    // Get old column names for mapping
    const oldColumns = [...columns];
    
    // Update rows with new column structure
    const updatedRows = rows.map(row => {
      const newCells = {};
      
      // Map existing content to new columns where possible
      editingColumns.forEach((newColumn, index) => {
        if (index < oldColumns.length) {
          // If column was renamed, map old content to new name
          newCells[newColumn] = row.cells[oldColumns[index]] || '';
        } else {
          // For new columns, initialize with empty string
          newCells[newColumn] = '';
        }
      });
      
      return {
        ...row,
        cells: newCells
      };
    });
    
    // Update state
    setColumns(editingColumns);
    setRows(updatedRows);
    setShowColumnModal(false);
  };

  // Handle row drag start
  const handleRowDragStart = (index) => {
    setDraggedRowIndex(index);
  };

  // Handle row drag over
  const handleRowDragOver = (e, index) => {
    e.preventDefault();
    if (draggedRowIndex === null || draggedRowIndex === index) return;
    
    // Reorder rows
    const newRows = [...rows];
    const draggedRow = newRows[draggedRowIndex];
    newRows.splice(draggedRowIndex, 1);
    newRows.splice(index, 0, draggedRow);
    
    setRows(newRows);
    setDraggedRowIndex(index);
  };

  // Handle column drag start in modal
  const handleColumnDragStart = (index) => {
    setDraggedColumnIndex(index);
  };

  // Handle column drag over in modal
  const handleColumnDragOver = (e, index) => {
    e.preventDefault();
    if (draggedColumnIndex === null || draggedColumnIndex === index) return;
    
    // Reorder columns
    const newColumns = [...editingColumns];
    const draggedColumn = newColumns[draggedColumnIndex];
    newColumns.splice(draggedColumnIndex, 1);
    newColumns.splice(index, 0, draggedColumn);
    
    setEditingColumns(newColumns);
    setDraggedColumnIndex(index);
  };

  // Handle saving grid data
  const handleSaveGrid = () => {
    try {
      const gridData = {
        title,
        author,
        columns,
        rows
      };
      
      localStorage.setItem('narrativeGridData', JSON.stringify(gridData));
      alert('Grid saved successfully!');
    } catch (error) {
      console.error('Error saving grid:', error);
      alert('Failed to save grid. Please try again.');
    }
  };

  // Handle loading grid data
  const handleLoadGrid = () => {
    try {
      const savedData = localStorage.getItem('narrativeGridData');
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setTitle(parsedData.title || 'Untitled Story');
        setAuthor(parsedData.author || 'Anonymous');
        setColumns(parsedData.columns || []);
        setRows(parsedData.rows || []);
        
        // Update nextRowId to be greater than any existing row id
        const maxId = Math.max(...parsedData.rows.map(row => row.id), 0);
        setNextRowId(maxId + 1);
      } else {
        alert('No saved grid found.');
      }
    } catch (error) {
      console.error('Error loading grid:', error);
      alert('Failed to load grid. The saved data may be corrupted.');
    }
  };

  // Handle importing CSV
  const handleImportCSV = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv';
    
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const csvText = event.target.result;
          const lines = csvText.split('\\n');
          
          // Parse header row for columns
          const newColumns = lines[0].split(',').map(col => col.trim());
          
          // Parse data rows
          const newRows = [];
          let maxId = 0;
          
          for (let i = 1; i < lines.length; i++) {
            if (!lines[i].trim()) continue;
            
            const values = lines[i].split(',').map(val => val.trim());
            const rowCells = {};
            
            newColumns.forEach((col, index) => {
              rowCells[col] = values[index] || '';
            });
            
            const rowId = nextRowId + i - 1;
            maxId = Math.max(maxId, rowId);
            
            newRows.push({
              id: rowId,
              cells: rowCells
            });
          }
          
          setColumns(newColumns);
          setRows(newRows);
          setNextRowId(maxId + 1);
          
          alert('CSV imported successfully!');
        } catch (error) {
          console.error('Error importing CSV:', error);
          alert('Failed to import CSV. Please check the file format.');
        }
      };
      
      reader.readAsText(file);
    };
    
    input.click();
  };

  // Handle exporting to CSV
  const handleExportCSV = () => {
    try {
      // Create header row
      let csvContent = columns.join(',') + '\\n';
      
      // Add data rows
      rows.forEach(row => {
        const rowValues = columns.map(col => {
          // Escape commas and quotes in cell values
          const cellValue = row.cells[col] || '';
          const escapedValue = cellValue.replace(/"/g, '""');
          return `"${escapedValue}"`;
        });
        
        csvContent += rowValues.join(',') + '\\n';
      });
      
      // Create download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `${title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_narrative_grid.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error exporting CSV:', error);
      alert('Failed to export CSV. Please try again.');
    }
  };

  // Handle resetting the grid
  const handleResetGrid = () => {
    if (window.confirm('Are you sure you want to reset the grid? This will clear all your data.')) {
      setTitle('Untitled Story');
      setAuthor('Anonymous');
      setColumns([
        'Act',
        'Plot Movement (What Happens)',
        'Character Evolution',
        'Core Theme / Message',
        'Supporting Subplot(s)',
        'Relationship Dynamics',
        'Setting / Location',
        'Point of View (POV)',
        'Emotional Beats',
        'Conflict Type',
        'Scene Value Shift',
        'Turning Points',
        'Pacing / Tension',
        'Symbolism / Motifs'
      ]);
      setRows([
        {
          id: 1,
          cells: {
            'Act': '1',
            'Plot Movement (What Happens)': '',
            'Character Evolution': '',
            'Core Theme / Message': '',
            'Supporting Subplot(s)': '',
            'Relationship Dynamics': '',
            'Setting / Location': '',
            'Point of View (POV)': '',
            'Emotional Beats': '',
            'Conflict Type': '',
            'Scene Value Shift': '',
            'Turning Points': '',
            'Pacing / Tension': '',
            'Symbolism / Motifs': ''
          }
        }
      ]);
      setNextRowId(2);
    }
  };

  // Load saved data on component mount
  useEffect(() => {
    try {
      const savedData = localStorage.getItem('narrativeGridData');
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setTitle(parsedData.title || 'Untitled Story');
        setAuthor(parsedData.author || 'Anonymous');
        setColumns(parsedData.columns || []);
        setRows(parsedData.rows || []);
        
        // Update nextRowId to be greater than any existing row id
        const maxId = Math.max(...parsedData.rows.map(row => row.id), 0);
        setNextRowId(maxId + 1);
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
  }, []);

  return (
    <div className="narrative-grid-editor">
      <div className="grid-header">
        <div className="grid-title-section">
          <div className="grid-input-group">
            <label htmlFor="story-title">Story Title:</label>
            <input
              id="story-title"
              type="text"
              className="grid-title-input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="grid-input-group">
            <label htmlFor="story-author">Author:</label>
            <input
              id="story-author"
              type="text"
              className="grid-author-input"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
            />
          </div>
        </div>
        <div className="grid-action-buttons">
          <button className="grid-action-button save" onClick={handleSaveGrid}>
            Save Grid
          </button>
          <button className="grid-action-button load" onClick={handleLoadGrid}>
            Load Grid
          </button>
          <button className="grid-action-button import" onClick={handleImportCSV}>
            Import CSV
          </button>
          <button className="grid-action-button export" onClick={handleExportCSV}>
            Export CSV
          </button>
          <button className="grid-action-button reset" onClick={handleResetGrid}>
            Reset
          </button>
          <button className="grid-action-button columns" onClick={() => setShowColumnModal(true)}>
            Manage Columns
          </button>
        </div>
      </div>
      
      <div className="narrative-grid-container">
        <table className="narrative-grid">
          <thead>
            <tr>
              <th>Actions</th>
              {columns.map((column, index) => (
                <th key={index} className="grid-header-cell">
                  {column}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, rowIndex) => (
              <tr
                key={row.id}
                className={rowIndex === draggedRowIndex ? 'grid-row-dragging' : ''}
                draggable
                onDragStart={() => handleRowDragStart(rowIndex)}
                onDragOver={(e) => handleRowDragOver(e, rowIndex)}
              >
                <td>
                  <div className="grid-row-actions">
                    <div className="grid-row-handle" title="Drag to reorder">≡</div>
                    <button
                      className="grid-row-delete"
                      onClick={() => handleDeleteRow(row.id)}
                      title="Delete row"
                    >
                      🗑️
                    </button>
                  </div>
                </td>
                {columns.map((column, colIndex) => (
                  <td key={colIndex}>
                    <textarea
                      className="grid-cell-content"
                      value={row.cells[column] || ''}
                      onChange={(e) => handleCellChange(row.id, column, e.target.value)}
                      placeholder="Enter content..."
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <button className="add-row-button" onClick={handleAddRow}>
        + Add Row
      </button>
      
      {showColumnModal && (
        <div className="column-modal">
          <div className="column-modal-content">
            <div className="column-modal-header">
              <h3 className="column-modal-title">Manage Columns</h3>
              <button
                className="column-modal-close"
                onClick={() => setShowColumnModal(false)}
              >
                ×
              </button>
            </div>
            
            <div className="column-list">
              {editingColumns.map((column, index) => (
                <div
                  key={index}
                  className="column-item"
                  draggable
                  onDragStart={() => handleColumnDragStart(index)}
                  onDragOver={(e) => handleColumnDragOver(e, index)}
                >
                  <div className="column-handle" title="Drag to reorder">≡</div>
                  <input
                    type="text"
                    className="column-input"
                    value={column}
                    onChange={(e) => handleColumnChange(index, e.target.value)}
                  />
                  <button
                    className="column-delete"
                    onClick={() => handleDeleteColumn(index)}
                    title="Delete column"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            
            <button className="add-column-button" onClick={handleAddColumn}>
              + Add Column
            </button>
            
            <div className="column-modal-actions">
              <button
                className="column-modal-button cancel"
                onClick={() => setShowColumnModal(false)}
              >
                Cancel
              </button>
              <button
                className="column-modal-button save"
                onClick={handleSaveColumns}
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NarrativeGridEditor;
