import React from 'react';

const StoryGridsLogo = ({ size = 32 }) => {
  const gridSize = size / 2;
  const gap = 2;
  const totalSize = size;
  
  const colors = [
    '#4285F4', // Google Blue
    '#5E97F6', // Lighter Blue
    '#3367D6', // Darker Blue
    '#7BAAF7', // Even Lighter Blue
  ];
  
  return (
    <svg width={totalSize} height={totalSize} viewBox={`0 0 ${totalSize} ${totalSize}`} xmlns="http://www.w3.org/2000/svg">
      {colors.map((color, index) => {
        const row = Math.floor(index / 2);
        const col = index % 2;
        const x = col * (gridSize + gap);
        const y = row * (gridSize + gap);
        
        return (
          <rect
            key={index}
            x={x}
            y={y}
            width={gridSize}
            height={gridSize}
            fill={color}
            rx={2}
            ry={2}
          />
        );
      })}
    </svg>
  );
};

export default StoryGridsLogo;
