import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ModeSelector from './components/ModeSelector';
import NarrativeGridEditor from './components/NarrativeGridEditor';
import SnowflakeMethod from './components/SnowflakeMethod';
import StoryGridsLogo from './components/StoryGridsLogo';
import './index.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passkey, setPasskey] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const correctPasskey = 'STORYTELLER311';

  // Check for saved authentication
  useEffect(() => {
    try {
      const savedAuth = localStorage.getItem('storyGridsAuth');
      if (savedAuth === 'true') {
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error('Error checking authentication:', error);
      // Continue without saved auth if localStorage fails
    }
  }, []);

  const handlePasskeySubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      if (passkey.toUpperCase() === correctPasskey) {
        setIsAuthenticated(true);
        try {
          localStorage.setItem('storyGridsAuth', 'true');
        } catch (error) {
          console.error('Error saving authentication:', error);
          // Continue even if localStorage fails
        }
      } else {
        alert('Incorrect passkey. Please try again.');
      }
    } catch (error) {
      console.error('Error in authentication:', error);
      alert('An error occurred during authentication. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasskeyChange = (e) => {
    setPasskey(e.target.value);
  };

  // Direct authentication option for testing or if modal fails
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Allow direct authentication with Ctrl+Alt+A for testing
      if (e.ctrlKey && e.altKey && e.key === 'a') {
        setIsAuthenticated(true);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!isAuthenticated) {
    return (
      <div className="auth-container">
        <div className="auth-box">
          <div className="centered-logo">
            <StoryGridsLogo size={64} />
            <h1>Story Grids</h1>
          </div>
          <p>Enter the passkey to access Story Grids</p>
          <form className="passkey-form" onSubmit={handlePasskeySubmit}>
            <input
              type="password"
              className="passkey-input"
              value={passkey}
              onChange={handlePasskeyChange}
              placeholder="Enter passkey"
              autoFocus
              disabled={isSubmitting}
            />
            <button 
              type="submit" 
              className="action-button save"
              disabled={isSubmitting}
              style={{ height: '45px' }} // Ensure consistent height
            >
              {isSubmitting ? 'Submitting...' : 'Submit'}
            </button>
          </form>
          <div style={{ marginTop: '15px', fontSize: '14px', color: 'var(--text-color-secondary)' }}>
            Passkey: STORYTELLER311
          </div>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="app">
        <header className="app-header">
          <div className="logo-container">
            <StoryGridsLogo size={32} />
            <h1 className="app-title">Story Grids</h1>
          </div>
        </header>
        
        <div className="app-layout">
          <main className="app-main">
            <ModeSelector />
            
            <Routes>
              <Route path="/grid" element={<NarrativeGridEditor />} />
              <Route path="/snowflake" element={<SnowflakeMethod />} />
              <Route path="*" element={<Navigate to="/grid" replace />} />
            </Routes>
          </main>
          
          <footer className="app-footer">
            <p>© {new Date().getFullYear()} Story Grids - A tool for writers</p>
          </footer>
        </div>
      </div>
    </Router>
  );
}

export default App;
