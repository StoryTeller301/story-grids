import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

// Script to remove any Manus editor elements
document.addEventListener('DOMContentLoaded', function() {
  // Function to remove editor elements
  const removeEditorElements = () => {
    const selectors = [
      'manus-content-root',
      '.footer-btn',
      '[data-manus-editor="true"]',
      '[class*="manus-editor"]',
      '[id*="manus-editor"]'
    ];
    
    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
      elements.forEach(el => el.remove());
    });
    
    // Also check for shadow DOM elements
    document.querySelectorAll('*').forEach(el => {
      if (el.shadowRoot) {
        const shadowElements = el.shadowRoot.querySelectorAll('*');
        shadowElements.forEach(shadowEl => {
          if (shadowEl.textContent.includes('Edit mode') || 
              (shadowEl.className && shadowEl.className.includes('editor'))) {
            shadowEl.style.display = 'none';
            shadowEl.style.visibility = 'hidden';
            shadowEl.style.opacity = '0';
            shadowEl.style.pointerEvents = 'none';
          }
        });
      }
    });
  };
  
  // Run immediately and set up a mutation observer
  removeEditorElements();
  
  // Set up observer to catch dynamically added elements
  const observer = new MutationObserver((mutations) => {
    removeEditorElements();
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
